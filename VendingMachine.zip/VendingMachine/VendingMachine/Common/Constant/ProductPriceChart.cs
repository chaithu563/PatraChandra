﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine.Common
{
    public static class ProductPriceChart
    {

        public const double Cola = 1.0;
        public const double Chips = 0.5;
        public const double Candy = 0.65;

    }
}
