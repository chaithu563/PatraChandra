﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine.Common
{
    public enum ProductName
    {
        Cola = 1,
        Chips = 2,
        Candy = 3,
    }
}
